# run this command in the OUTPUT FOLDER TO MERGE THE SD AND DS LIBRARIES OF THE INDIVIDUAL BEDS
#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh AltaiNeanderthal MethylMap HOXD10 &
#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh AltaiNeanderthal MethylMap methyl450k2000 &
#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh AltaiNeanderthal MethylMap RRBSk1500 &

#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh Loschbour MethylMap HOXD10 &
#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh Loschbour MethylMap methyl450k2000 &
#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh Loschbour MethylMap RRBSk1500 &

#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh Denisova MethylMap HOXD10 &
#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh Denisova MethylMap methyl450k2000 &
#nice -n 19 /home/krishang/bin/merge_multiplebeds.sh Denisova MethylMap RRBSk1500 &

#nice -n 19 /home/krishang/data/methyl_rawdata/merge_multiplebeds.sh Loschbour MethylMap RRBSk1500 &
nice -n 19 /home/krishang/data/methyl_rawdata/merge_multiplebeds.sh Denisova MethylMap RRBSk1500 &
nice -n 19 /home/krishang/data/methyl_rawdata/merge_multiplebeds.sh AltaiNeanderthal MethylMap RRBSk1500 &
